var app = angular.module('airnwater-app');

app.controller('adminCtrl', function(){

});
