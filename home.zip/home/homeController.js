var app = angular.module('airnwater-app');

app.controller('homeCtrl', function(){

});
